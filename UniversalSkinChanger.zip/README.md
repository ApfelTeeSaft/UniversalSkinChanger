# UniversalSkinChanger

## Whats this exactly?
- It's a very basic attempt at a Universal Skin Changer DLL using the ServerChoosePart function and Reboots addresses system (Credits to [Milxnor](https://github.com/milxnor))
- It is **NOT** meant for latest, but rather for Private Servers, i do not condone Cheating or DLL injection into the Official Fortnite Servers, and won't be responsible if ur too stupid and get your account Banned
- It **can** be Patched out by some Custom Gameservers, but as of the 30th of October 2024, it works on Vanilla Reboot!

## Where can I download a Prebuilt DLL?
- Just get it from the Releases section from this Repository
- **NOTE** a Injector with a GUI to change ur skin (a similar GUI to the FortnitePorting Tool) is planned for the Future!

## Contributing
- Contributions are always Welcome!!!

## License
- This Repo is licensed under the MIT License
