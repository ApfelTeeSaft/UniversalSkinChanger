#pragma once
#include "globals.h"

namespace Addresses
{
	void SetupVersion();
}